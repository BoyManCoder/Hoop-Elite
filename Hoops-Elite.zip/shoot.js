function shotmeter {
  
}